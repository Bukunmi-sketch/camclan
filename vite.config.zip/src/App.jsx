// import { useState } from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Leftbar from './components/leftbar';
import Header from './components/header';
import Middle from './components/middle';
import './css/left.css';
import './css/app.css'
import './css/table.css'
import './css/dashboard.css'
import Custom from './components/custom';
import Modal from './components/modal';
import Register from './pages/register';
import Login from './pages/login';
import Contact from './pages/contact';

function App() {
  // const [count, setCount] = useState(0)

  return (
    <>
      <BrowserRouter>
        <Routes>

          <Route path='/dashboard' element={
            <>
              <Header />
              <main>
                <div className="container">
                  <Leftbar />
                  <Middle />
                </div>
              </main>


            </>
          } />

          <Route path='/sfu' element={
            <>
              <Header />
              <Leftbar />
            </>
          } />

          <Route path='/p2p' element={
            <>
              <Header />
              <Leftbar />
            </>
          } />

          <Route path='/custom' element={
            <>
              <Header />
              <main>
                <div className="container">
                  <Leftbar />
                  <Modal />
                  <Custom />
                </div>
              </main>
            </>
          } />

          <Route path='/register' element={
            <Register />
          } />

          <Route path='/login' element={
            <Login />
          } />

          <Route path='/contact' element={
            <Contact />
          } />

          {/* <Route path='/about' element={<Aboutus />} /> */}
          <Route path="*" element={Error} />

        </Routes>

      </BrowserRouter>
    </>
  )
}

export default App
